from pathlib import Path
from playwright.sync_api import sync_playwright
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
import threading,json,traceback
import os
ROOT=Path(os.environ['WQ_R2_ROOT']).expanduser().resolve()
OUT=Path(os.environ.get('WQ_AUDIT_OUT','audit_output')).expanduser().resolve()
OUT.mkdir(parents=True,exist_ok=True)
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',8873),partial(Quiet,directory=str(ROOT)));threading.Thread(target=server.serve_forever,daemon=True).start()
records=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('WQ_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 for url in ['http://127.0.0.1:8873/app/index.html',(ROOT/'app/index.html').as_uri()]:
  page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  row={'url':url}
  try:
   page.goto(url,wait_until='domcontentloaded',timeout=10000);page.wait_for_timeout(600)
   row['title']=page.title();row['text']=page.locator('body').inner_text()[:1600]
   row['features']=page.evaluate('''()=>{let store;try{localStorage.setItem('gap-audit-probe','ok');store=localStorage.getItem('gap-audit-probe');localStorage.removeItem('gap-audit-probe')}catch(e){store=e.message}return {storage:store,locks:!!navigator.locks,crypto:!!crypto.subtle,secure:isSecureContext,math:!!window.WQMathApp,r2:!!window.WQR2}}''')
   page.screenshot(path=str(OUT/('native_http.png' if url.startswith('http') else 'native_file.png')))
  except Exception as e:row['error']=str(e)
  row['page_errors']=errors;records.append(row);page.close()
 b.close()
server.shutdown();(OUT/'native_probe.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print(json.dumps(records,ensure_ascii=False,indent=2))
