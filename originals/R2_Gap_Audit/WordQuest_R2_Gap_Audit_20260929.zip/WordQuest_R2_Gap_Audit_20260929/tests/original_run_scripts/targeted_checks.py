from pathlib import Path
import sys,json,traceback
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data/r2_gap_audit/source/WordQuest_Arcade_R2');OUT=Path('/mnt/data/r2_gap_audit/evidence')
sys.path.insert(0,str(ROOT/'tests'));import harness
R2_HTML=harness.HTML
records=[]
def rec(name,observed,classification='observation'):
 records.append({'id':f'T{len(records)+1:02d}','name':name,'classification':classification,'observed':observed});(OUT/'targeted_checks.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print(name,json.dumps(observed,ensure_ascii=False)[:1100],flush=True)
def mc(p,a):p.locator(f'#wqm-app-host [data-action="{a}"]').first.click();p.wait_for_timeout(70)
def ms(p):return p.evaluate('WQMathApp.getState()')
def op(p,r='home'):
 p.evaluate('(r)=>WQMathApp.open(r)',r)
 if r!='home' and p.evaluate('WQMathApp.getView()')=='resume':mc(p,'nav:'+r)
def close(p):p.evaluate('WQMathApp.close()')
def answer(p):
 q=p.evaluate('''()=>{const s=WQMathApp.getState().current,r=s.queues[s.stage][s.index];return WQMathCore.generate(WQMathCore.library(WQMathData),r.template,r.seed)}''')
 if q['type']=='choice':mc(p,'choice:'+str(next(i for i,v in enumerate(q['choices']) if str(v['value'])==str(q['answer']))))
 else:
  p.locator('#wqm-app-host #answer').fill(str(q['answer']))
  if q['type']=='word':
   z=q['params'];p.locator('#wqm-app-host #expression').fill(q.get('expression') or (f"{z['paid']}-{z['qty']}*{z['price']}" if 'qty' in z else f"{z['paid']}-{z['price']}"));p.locator('#wqm-app-host #unit').select_option('元')
  if q['type']=='remainder':p.locator('#wqm-app-host #remainder').fill(str(q['remainder']))
 mc(p,'submit');return q

def gate(p,route='settings'):
 close(p);p.evaluate('(r)=>location.hash="#"+r',route);p.wait_for_timeout(100)
 if p.locator('#v23-parent-password').count():
  p.locator('#v23-parent-password').fill('R1testPass99');p.locator('[data-v23="parent-unlock"]').click();p.wait_for_function('WQMathHost.parentAllowed()')
 p.wait_for_timeout(100)

with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 try:
  # Build a genuine old standalone backup using its original UI and actual answer click.
  harness.HTML=(ROOT/'originals/WordQuest_Program_and_Data_20260929/02_Maths_0.1.2/WordQuest_Maths_0.1.2.html').read_text()
  oldctx,old,oe,od=harness.boot(b)
  mc(old,'nav:profiles');old.locator('#wqm-app-host #nickname').fill('舊數學測試學員');old.locator('#wqm-app-host #consent').check();mc(old,'create-profile')
  mc(old,'nav:normal');mc(old,'grade:1');mc(old,'practice:1N1.1');answer(old);mc(old,'nav:parent');mc(old,'nav:parent')
  with old.expect_download() as di:mc(old,'export')
  di.value.save_as(str(OUT/'synthetic_old_standalone_maths.json'));old_backup=json.loads((OUT/'synthetic_old_standalone_maths.json').read_text())
  rec('舊獨立版實際建立並匯出的數學備份',{'owner':old_backup['owner'],'attempts':len(old_backup['state']['attempts']),'format':old_backup['format'],'page_errors':oe});oldctx.close()
 except Exception:rec('舊版備份建立測試中斷',traceback.format_exc(),'test_error');old_backup=None
 harness.HTML=R2_HTML
 try:
  ctx,p,errors,dialogs=harness.boot(b);profile=harness.register(p,name='GapAuditFamily',child='整合缺漏測試學員');rec('R2建立測試帳戶',profile)
  op(p,'normal');mc(p,'grade:1');mc(p,'practice:1N1.1');q=answer(p);state1=ms(p);rec('R2實際提交數學答案',{'correct':state1['current']['feedback']['correct'],'attempts':len(state1['attempts'])})
  gate(p)
  with p.expect_download() as di:p.locator('[data-act="export-data"]').first.click()
  di.value.save_as(str(OUT/'synthetic_english_export.json'));exp=json.loads((OUT/'synthetic_english_export.json').read_text())
  rec('主設定頁匯出備份的內容',{'download_name':di.value.suggested_filename,'top_level_keys':list(exp),'math_keys':[k for k in exp if 'math' in k.lower()],'math_attempts_in_separate_store':len(state1['attempts'])},'confirmed_gap')
  op(p,'parent')
  with p.expect_download() as di:mc(p,'export')
  di.value.save_as(str(OUT/'synthetic_r2_maths_export.json'));own_backup=json.loads((OUT/'synthetic_r2_maths_export.json').read_text());rec('R2數學另行匯出',{'owner':own_backup['owner'],'attempts':len(own_backup['state']['attempts'])})
  if old_backup:
   mc(p,'import');p.locator('#wqm-app-host #import-file').set_input_files(str(OUT/'synthetic_old_standalone_maths.json'));p.wait_for_timeout(150)
   rec('把舊獨立版真實匯出檔匯入R2',{'message':p.locator('#wqm-app-host #toast').inner_text(),'old_owner':old_backup['owner'],'current_owner':own_backup['owner'],'current_attempts_unchanged':len(ms(p)['attempts'])==len(state1['attempts'])},'confirmed_gap')
   p.screenshot(path=str(OUT/'old_maths_import_rejected.png'),full_page=True)
  # Successful same-owner import provides an internal control and creates a recovery sidecar.
  mc(p,'import');p.locator('#wqm-app-host #import-file').set_input_files(str(OUT/'synthetic_r2_maths_export.json'));p.wait_for_timeout(100)
  rec('同帳戶同孩子備份還原對照',{'attempts':len(ms(p)['attempts']),'toast':p.locator('#wqm-app-host #toast').inner_text()})
  mc(p,'nav:normal');mc(p,'grade:4');rec('小四課程實際入口',{'playable_buttons':p.locator('#wqm-app-host [data-action^="lesson:"]').count(),'pending_labels':p.locator('#wqm-app-host main').inner_text().count('待開發')},'confirmed_gap');p.screenshot(path=str(OUT/'grade4_empty.png'),full_page=True)
  for g in [5,6]:mc(p,'grade:'+str(g));rec(f'小{g}課程實際入口',{'playable_buttons':p.locator('#wqm-app-host [data-action^="lesson:"]').count()},'confirmed_gap')
  mc(p,'nav:olympiad');rec('奧數實際範圍',{'text':p.locator('#wqm-app-host main').inner_text()[-700:],'lessons':p.locator('#wqm-app-host [data-action^="lesson:"]').count()},'confirmed_gap')
  mc(p,'nav:tools');rec('教具實際入口',p.locator('#wqm-app-host [data-action^="selecttool:"]').all_text_contents(),'coverage')
  mc(p,'nav:normal');mc(p,'grade:2');mc(p,'practice:2N5.3');q=p.evaluate('''()=>{const s=WQMathApp.getState().current,r=s.queues[s.stage][s.index];return WQMathCore.generate(WQMathCore.library(WQMathData),r.template,r.seed)}''')
  rec('應用題填答格',{'type':q['type'],'stem':q.get('stem_zh'),'fields':p.locator('#wqm-app-host input,#wqm-app-host select,#wqm-app-host textarea').evaluate_all('(xs)=>xs.map(x=>({id:x.id,placeholder:x.placeholder||"",tag:x.tagName}))')},'coverage')
  if q['type']=='word':
   z=q['params'];p.locator('#wqm-app-host #expression').fill(f"{z['paid']}-{z['price']}");p.locator('#wqm-app-host #answer').fill(str(q['answer']));p.locator('#wqm-app-host #unit').select_option('元')
   sent_before=p.locator('#wqm-app-host #sentence').inner_text();mc(p,'submit');sent_after=p.locator('#wqm-app-host #sentence').inner_text()
   rec('應用題答句在提交後重繪',{'before':sent_before,'after':sent_after,'correct':ms(p)['current']['feedback']['correct']},'confirmed_bug' if sent_before!=sent_after else 'control_pass');p.screenshot(path=str(OUT/'answer_sentence_reset.png'),full_page=True)
  # Reset all uses the same default child identifier; inspect whether old math remains.
  close(p);gate(p)
  before=p.evaluate('''()=>({profile:WQMathHost.profile(),keys:Object.keys(localStorage.dump()).filter(k=>k.startsWith('wqm-state-v1:')),math:Object.fromEntries(Object.entries(localStorage.dump()).filter(([k])=>k.startsWith('wqm-state-v1:')))})''')
  p.locator('[data-act="reset-all"]').click();p.wait_for_timeout(100)
  after=p.evaluate('''()=>({profile:WQMathHost.profile(),keys:Object.keys(localStorage.dump()).filter(k=>k.startsWith('wqm-state-v1:')),math:Object.fromEntries(Object.entries(localStorage.dump()).filter(([k])=>k.startsWith('wqm-state-v1:')))})''')
  p.evaluate("location.hash='#kid'");p.wait_for_timeout(60);op(p);resetstate=ms(p)
  rec('主設定清除目前帳戶資料後的數學紀錄',{'before_profile':before['profile'],'after_profile':after['profile'],'before_math_keys':before['keys'],'after_math_keys':after['keys'],'remaining_attempts':len(resetstate['attempts']),'remaining_current':bool(resetstate['current']),'unchanged_raw_keys':[k for k in before['math'] if before['math'][k]==after['math'].get(k)]},'confirmed_bug' if resetstate['attempts'] else 'control_pass')
  p.screenshot(path=str(OUT/'reset_retains_math.png'),full_page=True)
  rec('本次實際頁面未捕捉到JS例外',errors,'runtime_errors');ctx.close()
 except Exception:rec('R2測試中斷',traceback.format_exc(),'test_error')
 b.close()
