from pathlib import Path
import sys,json,hashlib
from collections import Counter
from playwright.sync_api import sync_playwright
import os
ROOT=Path(os.environ['WQ_R2_ROOT']).expanduser().resolve()
OUT=Path(os.environ.get('WQ_AUDIT_OUT','audit_output')).expanduser().resolve()
OUT.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(ROOT/'tests'));import harness
rows=[]
def rec(name,value):
 rows.append({'name':name,'observed':value});print(name,json.dumps(value,ensure_ascii=False)[:1800],flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path=os.environ.get('WQ_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 fixture=json.loads((ROOT/'arcade_evidence/test_fixture_initial.json').read_text())
 k=next(k for k in fixture['local'] if k.startswith('wordquest-v10-user-'));d=json.loads(fixture['local'][k]);d['children'][0]['stars']=40
 d.setdefault('arcadeV28',{'v':28,'children':{'c_demo':{'batch':{'number':1,'used':0,'lastSpentAt':0},'days':{},'ledger':[],'run':None,'paused':False,'permissions':{},'selectedSkin':'classic','bests':{},'migration':{'original':40,'returned':0,'due':0,'at':0}}}})
 for v in d.get('arcadeV28',{}).get('children',{}).values():v.setdefault('permissions',{})['star-patrol']='open';v['batch']['used']=0
 fixture['local'][k]=json.dumps(d)
 ctx,p,errors,dialogs=harness.boot(b,390,initial=fixture)
 inventory=p.evaluate('''()=>({math:WQMathData,characters:Object.entries(WQ32Core.roles).map(([id,v])=>({id,name:v.name,poses:WQ32Core.poses})),arcade:WQArcade28.catalog.map(x=>({id:x.id,name:x.name})),newgames:WQR2.games.map(x=>({id:x.id,keys:x.keys,guide:x.guide})),voices:typeof speechSynthesis!=='undefined'?speechSynthesis.getVoices().map(v=>({lang:v.lang,name:v.name})):[]})''')
 md=inventory.pop('math');summary={'units':len(md['units']),'unit_status':dict(Counter(v['status'] for v in md['units'])),'normal_skills':sum(v['track']=='normal' for v in md['skills']),'normal_skills_by_grade':dict(Counter(v['grade'] for v in md['skills'] if v['track']=='normal')),'normal_skills_by_strand':dict(Counter(v['strand'] for v in md['skills'] if v['track']=='normal')),'olympiad_skills':sum(v['track']=='olympiad' for v in md['skills']),'templates':len(md['templates']),'strategy_cards':[c['name'] for c in md['cards']],'planned_units':[{'id':u['id'],'name':u['name'],'grade':u['grade']} for u in md['units'] if not u['skills']]}
 (OUT/'runtime_inventory.json').write_text(json.dumps({'summary':summary,**inventory},ensure_ascii=False,indent=2));rec('實際載入題庫、角色及遊戲數目',{**{k:v for k,v in summary.items() if k!='planned_units'},'arcade_count':len(inventory['arcade']),'characters':[v['name'] for v in inventory['characters']]})
 p.evaluate("location.hash='#game'");p.wait_for_selector('[data-cabinet="star-patrol"]');p.locator('[data-cabinet="star-patrol"] [data-a28="intro"]').click()
 buy=p.locator('#pg-dialog [data-a28="buy"]')
 if buy.is_disabled():
  rec('手機星環入口尚未解鎖',p.locator('#pg-dialog').inner_text())
 else:
  buy.click();p.wait_for_selector('#pg-canvas');p.locator('[data-a28="play"]').click();p.wait_for_timeout(120)
  controls=p.locator('.a28-touch-key').evaluate_all('(xs)=>xs.map(x=>({key:x.dataset.a28key,text:x.textContent,visible:!!x.getClientRects().length}))')
  rec('手機星環巡航操作鍵',{'keys':controls,'precision_slow_button':any(v['key']=='hold' for v in controls),'guide_requires_shift':'Shift' in next(g for g in inventory['newgames'] if g['id']=='star-patrol')['guide']})
  p.locator('[data-a28="pause"]').click();p.screenshot(path=str(OUT/'star_mobile_controls.png'),full_page=True)
 # Execute pure engine movement against real canvas in DOM, not the user's game or wallet.
 rec('精準慢移引擎本身存在',p.evaluate('''()=>{const meta=WQR2.games.find(x=>x.id==='star-patrol');const make=()=>{const c=document.createElement('canvas');c.width=800;c.height=560;return new meta.Class({meta,ctx:c.getContext('2d'),seed:123,difficulty:1,preview:false,tools(){},hint(){},announce(){},tone(){},music(){},clock(){return 0},instrument(){},complete(){},getData(){return null},putData(){},downloadJSON(){},importJSON(){}})};const a=make(),b=make();a.key('right',true);b.key('right',true);b.key('hold',true);a.tick(.05);b.tick(.05);return {normal_delta:a.p.x-400,slow_delta:b.p.x-400}}'''))
 rec('瀏覽器JS例外',errors);ctx.close();b.close()
(OUT/'extra_probes.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
