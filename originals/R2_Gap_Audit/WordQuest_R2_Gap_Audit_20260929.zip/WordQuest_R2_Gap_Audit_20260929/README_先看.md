# WordQuest R2 缺漏檢查資料包

日期：2026-09-29 21:21:05（香港時間）
檢查對象：WordQuest_Arcade_R2_Complete_20260929.zip
ZIP SHA-256：0e831fe01476ee7488d5bcbf4bd948bd8d0f57014810a4eedabf661cb1cccaaf
App SHA-256：4de1c712588f3ae1cb3b201138a336d347819cbf118a964f44ca7ad6e068c3ae

本包是檢查報告及重現資料，**不是修正版程式**。原R2未修改。先開 `REPORT.html` 閱讀；不用安裝Python。

## 證據範圍

本輪16項主流程觀察、4項補充觀察，不是20個互相獨立功能，也不是20項全部通過。重要結果是2項已重現程式缺陷、3項直接影響操作的缺口；另外按課程、整合及驗收分組列出7項主要不足。
原R2的555項及更早測試只是隨包歷史紀錄，本輪沒有重跑，不混入本輪通過筆數。
769個ZIP檔案CRC正常；原清單768個SHA-256全部相符。這些只證明檔案一致，不證明程式正確。

## 測試環境

真Chromium的DOM、點擊、填答及Blob下載。localStorage、sessionStorage、Web Locks、WebCrypto是明示隔離替身。
嘗試localhost和file網址被ERR_BLOCKED_BY_ADMINISTRATOR擋下；沒有繞過環境限制，亦沒有聲稱完成原生儲存驗收。
所有synthetic_*備份均由本輪虛構測試學員的實際操作產生，不是Oliver電腦內的學員或正式用戶資料。
「persistent:true」是應用程式所見測試身份屬性，不是原生永久儲存通過證明。

## 目錄

- REPORT.html：自包含中文報告，主要截圖已內嵌。
- findings.json：問題、根據、重現方法、建議修正及驗收條件。
- evidence/：最終JSON、測試備份、完整截圖及900px裁剪版本。
- source_excerpts/：可核對的原始碼節錄；inline script以BeautifulSoup的script節點由0起編號。
- tests/original_run_scripts/：實際執行時的原測試腳本。當中絕對路徑屬本輪隔離環境。
- tests/*.py：可攜化入口，只改測試檔案／瀏覽器路徑；已作Python語法檢查，未將可攜化版本再跑一輪。
- tests/harness_reference.py：原包測試替身副本，供審閱；實際載入的harness仍來自WQ_R2_ROOT/tests。

## 開發者重現

先完整解壓原R2套件。在有Python、Playwright及Chromium的隔離測試環境：

```sh
export WQ_R2_ROOT="/absolute/path/to/WordQuest_Arcade_R2"
export WQ_CHROMIUM="/absolute/path/to/chromium"
export WQ_AUDIT_OUT="/absolute/path/to/new_audit_output"
python tests/targeted_checks.py
python tests/extra_probes.py
python tests/native_probe.py
```

請在新的測試輸出目錄執行；腳本會建立／覆寫合成測試結果，不能指向正式用戶資料。
native_probe.py會在本機127.0.0.1:8873暫時提供唯讀測試頁。如平台阻擋，記錄限制便停止，不修改安全政策。

## 安全使用建議

修正前保留舊程式及原檔，英文和每個孩子的數學分別備份；有自訂媒體時再匯出教材包。
不要依賴「清除目前帳戶資料」已把所有數學資料刪掉；不要為搬移紀錄直接修改備份owner欄位。
本輪沒有推送GitHub、部署網站、讀取正式帳戶、發送電郵或改動原R2。
